/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tugas_5_pbo_kasus2;

/**
 *
 * @author Marshya N
 */
import java.util.Scanner;
public class Tugas_5_PBO_Kasus2 {

    public class PemesananMakanan {

        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            // Inisialisasi menu makanan
            Produk[] menuMakanan = {
                    new Produk("Nasi Goreng", 15000),
                    new Produk("Mie Goreng", 12000),
                    new Produk("Ayam Bakar", 25000),
                    new Produk("Soto Ayam", 18000),
                    new Produk("Bakso", 12000),
                    new Produk("Nasi Campur", 20000),
                    new Produk("Martabak", 18000),
                    new Produk("Sate Ayam", 15000),
                    new Produk("Capcay", 16000),
                    new Produk("Es Teh", 5000)
            };

            // Memulai pemesanan
            boolean pesanLain = true;
            double totalPembelian = 0;

            while (pesanLain) {
                // Menampilkan menu
                System.out.println("Menu Makanan:");
                for (int i = 0; i < menuMakanan.length; i++) {
                    System.out.println((i + 1) + ". " + menuMakanan[i].nama_produk + " - Rp. " + menuMakanan[i].harga);
                }

                // Memilih menu
                System.out.print("Pilih menu (1-" + menuMakanan.length + "): ");
                int pilihan = scanner.nextInt();
                pilihan--; // mengubah pilihan pengguna menjadi indeks array

                // Memasukkan jumlah pesanan
                System.out.print("Jumlah pesanan: ");
                int jumlahPesanan = scanner.nextInt();

                // Menghitung total harga pesanan
                double totalHarga = menuMakanan[pilihan].harga * jumlahPesanan;

                // Menampilkan detail pesanan
                System.out.println("Pesanan: " + menuMakanan[pilihan].nama_produk);
                System.out.println("Jumlah: " + jumlahPesanan);
                System.out.println("Harga per item: Rp. " + menuMakanan[pilihan].harga);
                System.out.println("Total harga: Rp. " + totalHarga);

                // Menambahkan total pembelian
                totalPembelian += totalHarga;

                // Konfirmasi pesan lagi
                System.out.print("Ingin memesan lagi? (ya/tidak): ");
                String jawaban = scanner.next();
                pesanLain = jawaban.equalsIgnoreCase("ya");
            }

            // Menampilkan total pembelian
            System.out.println("Total Pembelian: Rp. " + totalPembelian);

            // Menutup scanner
            scanner.close();
        }
    }

}
