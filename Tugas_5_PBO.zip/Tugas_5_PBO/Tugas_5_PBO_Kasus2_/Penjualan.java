/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tugas_5_pbo_kasus2;

/**
 *
 * @author Marshya N
 */
public class Penjualan {
    String nama_produk;
        int quantity;
        double harga_total;

        public Penjualan(String nama_produk, int quantity, double harga_total) {
            this.nama_produk = nama_produk;
            this.quantity = quantity;
            this.harga_total = harga_total;
        }
}
