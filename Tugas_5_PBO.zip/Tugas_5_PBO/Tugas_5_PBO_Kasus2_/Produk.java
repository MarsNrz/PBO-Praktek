/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tugas_5_pbo_kasus2;

/**
 *
 * @author Marshya N
 */
public class Produk {
    String nama_produk;
        double harga;
        int qty;

        public Produk(String nama_produk, double harga) {
            this.nama_produk = nama_produk;
            this.harga = harga;
            this.qty = 0;
        }
}
