/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tugas_5_pbo_kasus1;

/**
 *
 * @author Marshya N
 */
public class Tugas_5_PBO_Kasus1 {

}
