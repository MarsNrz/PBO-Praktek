/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tugas_4_pbo_kasus2;

/**
 *
 * @author Marshya N
 */

public class Tugas_4_PBO_Kasus2 {
    public static void main(String[] args) {
        Item name = new Item("upin");
    }
}

