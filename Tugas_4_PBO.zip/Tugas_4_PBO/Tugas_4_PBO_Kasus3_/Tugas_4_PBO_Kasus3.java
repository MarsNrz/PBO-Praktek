/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tugas_4_pbo_kasus3;

/**
 *
 * @author Marshya N
 */

//KelasDua
public class Tugas_4_PBO_Kasus3 {
    
}
