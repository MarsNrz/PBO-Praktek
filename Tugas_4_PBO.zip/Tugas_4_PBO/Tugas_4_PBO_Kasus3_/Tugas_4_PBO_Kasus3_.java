/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tugas_4_pbo_kasus3;

/**
 *
 * @author Marshya N
 */
public class Tugas_4_PBO_Kasus3_ {
    {
        System.out.println(5);
    }
    public static void main(String[] args) {
        System.out.println(6);
        KelasSatu satu = new KelasSatu(); 
        KelasSatu dua = new KelasSatu(10);
    }
}
