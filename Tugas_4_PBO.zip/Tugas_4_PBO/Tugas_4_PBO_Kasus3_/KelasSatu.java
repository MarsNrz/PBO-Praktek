/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tugas_4_pbo_kasus3;

/**
 *
 * @author Marshya N
 */
public class KelasSatu {
    {
        System.out.println(11);
    }
    
    static
    {
        System.out.println(2);
    }
    
    public KelasSatu(int i){
        System.out.println(3);
    }
    
    public KelasSatu(){
        System.out.println(4);
    }
}
